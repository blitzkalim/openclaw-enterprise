# 02 — Extension Strategy

## Principle: Bolt-on, Not Refactor

We add a single new directory: `src/team/` (parallel to `src/enterprise/` from the big plan but **much smaller** — think 600 lines, not 9,000). Everything else stays put.

OpenClaw core is **edited at exactly four points** — all of them are 5–25 line additions, all are guarded by an env flag, and all fall back to existing behavior when the flag is off.

## Where We Add Logic

```
┌──────────────────────────────────────────────────────────────────┐
│  HTTP request / WebSocket / Webhook                              │
└──────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│  src/team/auth-middleware.ts             (NEW, ~80 lines)        │
│    - Try team JWT/cookie → resolve user_id                       │
│    - Try API token → resolve user_id                             │
│    - Else fall through to existing OPENCLAW_GATEWAY_TOKEN check  │
└──────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│  src/gateway/auth.ts                     (PATCH, +15 lines)      │
│    - Call resolveTeamAuth() first                                │
│    - Attach { userId, workspaceId } to req                       │
│    - Existing token logic unchanged as fallback                  │
└──────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│  src/team/channel-router.ts              (NEW, ~150 lines)       │
│    POST /webhooks/whatsapp                                       │
│    POST /webhooks/telegram                                       │
│      → verify signature                                          │
│      → look up channel_identity (phone → user_id)                │
│      → set sessionKey = `user:${userId}:${threadId}`             │
│      → forward to existing agent runtime                         │
└──────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│  src/agents/agent-command.ts             (PATCH, +10 lines)      │
│    - Accept optional userId on the runtime request               │
│    - Pass it down to memory / session lookup                     │
│  (No changes to LLM call, tool dispatch, or streaming.)          │
└──────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│  src/sessions/session-key-utils.ts       (PATCH, +5 lines)       │
│    - When userId present, prefix session key with `u:${userId}:` │
│    - Else fall back to existing key derivation                   │
└──────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│  src/team/db.ts                          (NEW, ~120 lines)       │
│    - Better-sqlite3 over ~/.openclaw/team.sqlite                 │
│    - Tables: users, user_sessions, channel_identities,           │
│              workspaces (optional), api_tokens                   │
└──────────────────────────────────────────────────────────────────┘
```

## What We Don't Touch

- `src/agents/*` — agent runtime, tool dispatch, prompt building
- `src/channels/*` — channel core, binding compiler, allowlists
- `src/plugins/*` — plugin loader, plugin SDK
- `src/memory/*` — vector memory (we just key it by user)
- `src/config/*` — config IO, JSON5 parsing
- `extensions/*` — all 100+ extensions, including `telegram` and `whatsapp` plugins
- `ui/` — existing control UI (it keeps using `OPENCLAW_GATEWAY_TOKEN` or a per-user token)
- `src/cron/*`, `src/flows/*`, `src/skills/*`

## Activation Switch

The whole layer is gated by **one env var**:

```bash
OPENCLAW_TEAM_MODE=1
```

- Unset → OpenClaw behaves **bit-for-bit identical** to today. Single user, gateway token, no DB, no webhooks.
- Set → `src/team/init.ts` runs at boot:
  - Opens `~/.openclaw/team.sqlite` (creates schema if absent).
  - Registers `/auth/*` routes.
  - Registers `/webhooks/whatsapp` and `/webhooks/telegram`.
  - Installs the auth-middleware in front of the existing gateway auth.

This matches the enterprise plan's `DATABASE_URL` switch (`/kalim/enterprise-plan/16-backward-compatibility/`), but with SQLite + a single flag instead of Postgres + Redis.

## The Four Layers, in One Sentence

1. **Auth middleware** — resolves a `userId` if any team-mode credential is present.
2. **DB layer** — one SQLite file with five tiny tables.
3. **Channel router** — webhook endpoints that map sender → user → existing agent path.
4. **Session/memory keying** — prefix everything with `u:<userId>:` so two users on one install don't see each other's history.

That is the entire design. The next 10 sections expand each piece, but the picture above is the whole product.

## Why This Doesn't Become a Fork

- All four edits are inside `if (teamCtx) { … }` branches. Every existing call path is preserved.
- The new code lives in `src/team/`. Upstream rebases never touch it.
- Migration from upstream releases means resolving conflicts in 4 files (`auth.ts`, `agent-command.ts`, `session-key-utils.ts`, `index.ts`). Same exposure as a 200-line patch series.

## Why It Stays Small

| Big Plan | Simple Plan |
|---|---|
| Postgres + Redis + BullMQ + MinIO | SQLite file |
| JWT (RS256) + JWKS + refresh tokens | Cookie session + signed bearer for API |
| Tenant-router middleware | Single workspace assumed; optional table |
| RBAC matrix, role hierarchy | One bit: `is_admin` on users |
| Audit logger, billing meter, license check | Out of scope |
| Admin React dashboard (~3,000 lines) | Two minimal HTML pages: `/login` and `/team` |
| Gupshup + Meta + Twilio + Baileys multi-provider | Pick **one** WhatsApp path (Meta Cloud API webhook) + Telegram bot per workspace |
| 50+ new files | ~6 new files |

Everything cut here is recoverable: the big plan still applies if/when the project grows past 10 users.
