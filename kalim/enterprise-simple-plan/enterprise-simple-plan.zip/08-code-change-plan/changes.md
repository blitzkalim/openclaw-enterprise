# 08 — Code Change Plan

## Summary

| Category | Files | Approx Lines |
|---|---|---|
| **New** (`src/team/`) | 8 | ~700 |
| **Patch** (existing OpenClaw) | 4 | ~50 |
| **Total** | **12** | **~750** |

Compare to the big plan's `~9,200 lines, 50+ new files` (`/kalim/enterprise-plan/15-code-change-map/`). Same shape, ~12× smaller surface.

## New Files

All under `src/team/`. Self-contained: nothing in here is referenced from outside the four upstream patch points.

| File | Purpose | Lines |
|---|---|---|
| `src/team/index.ts` | Boot entrypoint; registers routes, opens DB, exports `resolveTeamAuth` | ~60 |
| `src/team/db.ts` | better-sqlite3 client + repository functions | ~150 |
| `src/team/db-migrate.ts` | Idempotent schema bootstrap (§07) | ~50 |
| `src/team/auth-middleware.ts` | Resolves cookie / API token / legacy → `TeamCtx` | ~80 |
| `src/team/auth-routes.ts` | `/auth/login`, `/auth/logout`, `/auth/me`, `/auth/reset` | ~120 |
| `src/team/team-routes.ts` | `/team` UI + `/team/users`, `/team/tokens`, `/team/identities` admin endpoints | ~200 |
| `src/team/channel-router.ts` | `/webhooks/whatsapp/:wsId` + `/webhooks/telegram/:wsId`, claim handler | ~150 |
| `src/team/web/` | Two static-rendered HTML pages (`login.html`, `team.html`) | ~150 |

## Patches to Existing OpenClaw

Each patch is a short, additive change inside an `if (teamCtx) { … }` guard. Rebases on upstream cost minutes, not hours.

| File | Current Purpose | Change Needed | Risk | Notes |
|---|---|---|---|---|
| `src/index.ts` | Process entry | Call `await initTeamModule()` after gateway boot if `OPENCLAW_TEAM_MODE=1` | **Low** | Wrapped in env-flag check |
| `src/gateway/auth.ts` | Bearer-token + Tailscale + proxy + device auth | At top of the existing authorize fn, call `resolveTeamAuth(req)`; on hit, attach `req.team` and return ok. On miss, fall through to existing logic untouched. | **Low** | ~15 lines; the entire existing chain is preserved |
| `src/gateway/server-http.ts` | Static route registration | Mount `auth-routes`, `team-routes`, `channel-router` only when team mode is on | **Low** | Two `if (TEAM_MODE) app.use(...)` lines |
| `src/sessions/session-key-utils.ts` | Derives session key from connection / channel | When `team.userId` is present in the derivation input, prefix the resulting key with `u:<userId>:` | **Low** | ~5 lines, default branch unchanged |
| `src/agents/agent-command.ts` | Agent runtime orchestrator (~1,200 lines) | Accept optional `team` on the runtime call's request shape; pass it into the per-call ctx so skills can read `ctx.team` | **Low–Medium** | ~10 lines, all additive; no logic changes |
| `package.json` | npm manifest | Add `better-sqlite3`, `argon2` (or use Node `crypto.scrypt` to avoid native deps); optionally `cookie` | **Low** | 2 deps |

### What we explicitly do NOT patch

| File | Why |
|---|---|
| `src/gateway/server-ws-runtime.ts` | WebSocket auth path is shared with HTTP via the same `authorize` function in `auth.ts`; one patch point covers both |
| `src/gateway/server-methods-list.ts` | We do not gate gateway methods by user role; not needed for "small team" |
| `src/config/io.ts` | Config stays in JSON5; we don't move it to DB |
| `src/channels/plugins/configured-binding-compiler.ts` | Channel bindings remain global; user mapping happens at the webhook router, not at the binding compiler |
| `src/agents/pi-tools.ts` and other tool files | No tenant-aware tool wrapping — simple plan trusts agents and tools |
| `extensions/telegram/`, `extensions/whatsapp/`, all `extensions/*` | Untouched. The webhook router in `src/team/channel-router.ts` is *additive* — it lives alongside the existing extensions |
| `src/plugins/*`, `src/skills/*`, `src/memory/*` | All unchanged |
| `ui/` (React control UI) | Unchanged. Continues to work with the gateway token. Team users open `/login` instead. |

## Patch Snippets (Reference)

### `src/index.ts`

```ts
import { initTeamModule } from './team';

async function main() {
  await initGateway();
  if (process.env.OPENCLAW_TEAM_MODE === '1') {
    await initTeamModule();
  }
}
```

### `src/gateway/auth.ts`

```ts
import { resolveTeamAuth } from '../team/auth-middleware';

export function authorizeHttpGatewayConnect(req) {
  if (process.env.OPENCLAW_TEAM_MODE === '1') {
    const team = resolveTeamAuth(req);
    if (team) {
      (req as any).team = team;
      return true;
    }
  }
  // Existing logic: gateway token, Tailscale, proxy, device-token
  return existingAuthLogic(req);
}
```

### `src/sessions/session-key-utils.ts`

```ts
export function deriveSessionKey(parts) {
  const base = existingDerivation(parts);          // unchanged
  const userId = parts.team?.userId;
  return userId ? `u:${userId}:${base}` : base;
}
```

### `src/agents/agent-command.ts` (the runtime entry)

```ts
// On the inbound runtime request shape:
type RuntimeRequest = {
  /* existing fields */
  team?: { userId: string; workspaceId: string | null; isAdmin: boolean };
};

// In the fn that constructs per-call ctx:
const ctx = {
  ...existingCtx,
  team: req.team,
};
```

That is the entirety of the agent-runtime change. No prompt logic, no tool dispatch, no streaming code is touched.

## Migration Risk Per Patch

| Patch point | Upstream churn likelihood | Conflict severity |
|---|---|---|
| `src/index.ts` boot | Low | Trivial — boot call is a one-liner |
| `src/gateway/auth.ts` | Medium (auth churns) | Low — our addition is at the top, before existing logic |
| `src/gateway/server-http.ts` | Medium (routes churn) | Low — our routes are namespaced under `/auth/*`, `/team/*`, `/webhooks/*` |
| `src/sessions/session-key-utils.ts` | Low | Trivial |
| `src/agents/agent-command.ts` | High (large file, active dev) | Low — additive optional field |
| `package.json` | Constant | Trivial |

The biggest exposure is `agent-command.ts` because it changes often. Mitigation: the only thing we add is "accept an extra optional field on the request shape and pass it through". If upstream renames the request shape, our patch follows the rename; we never depend on internal logic.

## Tests to Add

Bundled with the new files in `src/team/`:

| Test | What it asserts |
|---|---|
| `src/team/auth-middleware.test.ts` | Cookie, API token, legacy fallback all resolve correctly; bad creds 401 |
| `src/team/db.test.ts` | Schema migrates, repos round-trip, cascade deletes |
| `src/team/channel-router.test.ts` | Telegram secret-token check, WhatsApp HMAC verify, Mode-A claim flow, unknown sender drop |
| `src/team/integration.test.ts` | End-to-end: login → POST webhook → agent runtime gets `userId` → response sent |

Plus one **regression test** to assert that with `OPENCLAW_TEAM_MODE` unset, the existing OpenClaw test suite passes unchanged. This is the single most important guard against scope creep into upstream code.

## Build Integration

No bundler, no build-step changes. Same `tsc` invocation. `better-sqlite3` is the only native dep; document the prebuild for Linux/macOS/Windows in `09-deployment-model`.
