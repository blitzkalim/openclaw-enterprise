# 12 — Final Recommendation

## Three Direct Answers

### 1. Can this be built cleanly on OpenClaw?

**Yes, and the design is unusually small for what it delivers.**

- **~750 lines of code total.** 8 new files in `src/team/`, 4 patches to existing files (~50 lines).
- **Zero changes** to `src/agents/` internals, `src/channels/` core, `src/plugins/`, `src/skills/`, `src/memory/`, or any of the 100+ extensions.
- **Single env flag** (`OPENCLAW_TEAM_MODE=1`) toggles the whole layer. Off → byte-for-byte identical to today's OpenClaw.
- **Zero new infrastructure.** SQLite file, no Postgres, no Redis, no queue, no object store, no second process. Adds two npm deps: `better-sqlite3`, `argon2`.
- **Backward compatibility is by construction**, not by promise — the patches are guarded `if` branches, the new code is a parallel directory, the config file is untouched.

The reason this is so cheap is the key architectural insight buried in OpenClaw: **session keys flow through the entire runtime as the identity primitive**. By prefixing them with `u:<userId>:`, every downstream system — sessions, vector memory, tool ctx — becomes user-scoped automatically. We don't need to add `tenant_id` to twelve tables; we add it once, at the session-key boundary, and the rest of the codebase picks up the change for free.

### 2. Fastest implementation path?

**4 weeks, 1 engineer, calendar order:**

| Week | Deliverable |
|---|---|
| 1 | `src/team/db.ts` + schema + migrate(); `src/team/auth-middleware.ts` + cookie/API-token/legacy resolver; the 4 upstream patches; `/login` HTML; `/auth/me` working end-to-end |
| 2 | `src/team/team-routes.ts` (`/team` page, invite flow, API tokens UI); user-prefix in session keys; agent runtime accepts `team` ctx; multi-user regression test |
| 3 | `src/team/channel-router.ts`: Telegram webhook + secret-token verify; claim-code flow (Mode A); end-to-end "user → bot → agent → reply" working on Telegram |
| 4 | WhatsApp Meta Cloud webhook + HMAC; Mode-C guest user flow; encryption-at-rest for channel secrets; Caddy + docker-compose ship; docs |

If only **one channel** is needed: cut WhatsApp to Phase 2 and ship Telegram-only in 3 weeks. Telegram is strictly easier (free, simpler verification, no provider account approval).

### 3. What should be done first?

**The boot path and the auth middleware. In that order. Before anything else.**

Specifically, in the first 2–3 days:

1. Create `src/team/index.ts`, `src/team/db.ts`, `src/team/db-migrate.ts`. Get `OPENCLAW_TEAM_MODE=1` to start the process and create `~/.openclaw/team.sqlite` with the schema.
2. Implement `src/team/auth-middleware.ts` with all three credential paths.
3. Patch `src/gateway/auth.ts` and `src/index.ts` (the two minimal edits).
4. Write `src/team/integration.test.ts`: "with team mode on, hitting `/auth/me` with a fresh cookie session returns the user; with team mode off, the existing OpenClaw test suite passes unchanged."

Once that integration test is green, **the riskiest part of the project is done**. Everything else — channel-router, team UI, the WhatsApp webhook — is ordinary feature work that lives entirely in `src/team/` and requires no further upstream patches.

## Risk Watch List

| Risk | Mitigation |
|---|---|
| Upstream renames request shape on `agent-command.ts` | Our patch is the smallest possible additive field; rebases are minute-scale, not hour-scale |
| Meta Cloud API approval friction | Ship Telegram first; treat WhatsApp as Week-4 work, slip-able to Week 5/6 without touching plan |
| `better-sqlite3` native build issues on operator machines | Pin a known-good version, document prebuilt binaries, fall back to `node:sqlite` (Node 22.5+) if needed |
| Session-key prefix doesn't cover one obscure code path | Single integration test that asserts user A's history is invisible to user B catches it |
| Team grows to 50+ users | Switch SQLite → Postgres via `OPENCLAW_TEAM_DATABASE_URL`; same schema. If features start needing what big plan covers (RBAC, billing, audit), migrate then. Not before. |

## What Stays Out, Explicitly

The simple plan does **not** ship and does **not** plan to ship in v1:

- Multi-tenant SaaS, hostname-based tenant routing
- RBAC matrix, role tables, permission catalog
- Postgres + Redis + BullMQ
- Kubernetes, Helm
- JWT, JWKS, RS256, refresh tokens, MFA, OAuth, SSO
- Email password reset
- Audit logs, billing meter, license check
- Admin React dashboard (~3,000 lines)
- WhatsApp multi-provider abstraction
- Per-tenant agent configs, per-tenant tool boundaries
- Plugin sandboxing
- CRM connectors, lead schema, real-estate-specific data model
- Stripe billing, usage events, plan limits

Each of these is a real feature with real value at SaaS scale. Each is also a multi-week task with significant code and operational surface. The full enterprise plan (`/kalim/enterprise-plan/`) covers them. **This plan is the bridge that gets a small team using OpenClaw with WhatsApp/Telegram in a month — without committing to any of that scaffolding.**

## When to Graduate to the Full Enterprise Plan

Move only when at least one of these is true:

1. More than ~10 users active concurrently, or contention on the SQLite file is observable.
2. Real money is being made and a single-machine SPOF is a business risk.
3. A second customer/team needs hard isolation that workspace-segmentation alone doesn't provide (e.g. legal, compliance).
4. Per-user billing or usage metering is required.
5. RBAC beyond `is_admin` is genuinely needed (e.g. read-only roles for auditors).
6. SSO / OAuth is contractually mandated by a customer.

Until any of those hits: **resist scope creep**. The big plan is a roadmap, not a checklist. The simple plan is enough.

## One-Line Recommendation

> Ship the 750-line **`src/team/`** overlay. Telegram first, WhatsApp Meta-Cloud second. Single EC2, Docker Compose, SQLite. The big plan stays on the shelf until the project genuinely outgrows this one.
