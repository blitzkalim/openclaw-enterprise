# 06 — Agent Usage

## Rule: Don't Touch Agents

OpenClaw's agent system already does everything we need: model routing, prompt building, tool dispatch, streaming, memory hooks. Per `/kalim/enterprise-plan/09-agent-skill-plugin-model/`, the runtime handles ~1,200 lines of orchestration in `src/agents/agent-command.ts`. We add **zero** logic to it.

What we change is **how we call it**: with a user-scoped session key and a `team` context object. Everything downstream — agent config, skill loading, plugin hooks — stays identical.

## How Agents Are Reused

| Concern | Today (single user) | Team mode |
|---|---|---|
| Agent config | One global set in `~/.openclaw/openclaw.json` and `agents/` | **Same.** Shared across all users. |
| Skills | `skills/` and `extensions/*/skills/` | **Same.** Shared. |
| Plugin runtime | Loaded once per process | **Same.** Loaded once. |
| Session id | Derived from connection / channel thread | Prefixed: `u:<userId>:…` |
| Vector memory | One LanceDB table per agent | **Partitioned by `userId`** (see below) |
| Tools | All tools in agent's allowlist available to caller | **Same.** No per-user tool gating. |

The simple plan does **not** support per-user or per-workspace agent configs. All users share the same agent fleet. If a team needs different agents for different sub-teams, they create a workspace and write that into the agent's system prompt or skill logic — not into the runtime.

This is a real cut from the big plan, where `agent_configs` is a per-tenant Postgres table. We trade flexibility for ~500 lines of code we don't write.

## Attaching User Context

The `team` object flows from auth → router → runtime as an opaque field:

```ts
type TeamCtx = {
  userId: string;
  workspaceId: string | null;
  isAdmin: boolean;
  source: 'cookie' | 'api-token' | 'legacy';
};
```

It is plumbed into the runtime call but the runtime itself **only uses two fields**:

1. `userId` — for session keying and memory partitioning
2. `workspaceId` — only if the install has multiple workspaces; usually ignored

Skills and plugins that want user info read it from the runtime's request context (`ctx.team`). Most don't need to. The lead-capture skill (a starter agent in the big plan) does, because it stamps `assigned_to = userId` on new lead records.

## Per-User Memory Isolation

OpenClaw's vector memory (`src/memory/`) keys entries by a session id. We make sure every entry for a given user is namespaced under that user.

Two equivalent strategies; pick whichever the existing memory layer makes easiest:

**Strategy 1 — Prefix the session id (preferred)**

The session-key util (`src/sessions/session-key-utils.ts`) gets a 5-line edit:

```ts
export function deriveSessionKey(parts) {
  const base = existingDerivation(parts);
  if (parts.team?.userId) return `u:${parts.team.userId}:${base}`;
  return base;
}
```

LanceDB / vector lookups already key on session id, so this gives free isolation. No memory layer changes.

**Strategy 2 — Add a `user_id` filter in memory queries**

Edit memory query call sites in `src/memory/` to include a `user_id` predicate. Bigger change, more files touched, more risk. **We don't do this.** We use Strategy 1.

## Conversation History per User

OpenClaw stores per-session history in `~/.openclaw/sessions/*.json` keyed by session id. Once session ids are user-prefixed (Strategy 1 above), a user's chat history is automatically isolated. Two users on one install cannot see each other's transcripts.

For channel-driven conversations, the session key is `u:<userId>:<channel>:<threadId>`, so a user's WhatsApp thread, Telegram thread, and web-UI thread are all separate but all attributed to them.

## What Agents See in Their Tool Calls

When the agent runtime calls a tool, the tool gets the existing OpenClaw call context **plus** `ctx.team`. A skill that wants to record "lead created by Amit" reads `ctx.team.userId`. A skill that doesn't care ignores it. **No tool is forced to change.** Existing tools and skills work as-is.

## Concurrency

Two users on the same install hitting the same agent at the same time:

- Agent runtime is reentrant — that's already true today (one user can have many concurrent sessions).
- Memory writes are SQLite/LanceDB and serialize per file.
- LLM calls are independent HTTP requests upstream.
- No new locking is needed.

## What We Are NOT Doing

- ❌ **Per-tenant agent configs.** Big plan: `agent_configs` Postgres table. Simple plan: one global config.
- ❌ **Tenant tool boundaries.** Big plan: `tools_enabled` JSONB filtered per tenant. Simple plan: agent allowlists are global.
- ❌ **Per-user model picking.** All users use whatever model the agent is configured with.
- ❌ **Per-user rate limiting on LLM tokens.** No usage meter, no billing. Out of scope.
- ❌ **Subagent isolation.** Subagents inherit parent's `team` context.
- ❌ **Plugin sandboxing.** Plugins run in-process as today. We trust the plugins the operator installs.

## Migration Path When You Outgrow This

If the team needs per-user agent configs or per-user model overrides, the big plan's `agent_configs` table drops in cleanly: it's keyed by `tenant_id`, which we'd map to `workspace_id`. The runtime patch (~10 lines today) extends to look up agent config by workspace before falling back to global. That's the only change. Everything else carries over.

## Net Code Change to Agent Layer

| File | Change | Lines |
|---|---|---|
| `src/agents/agent-command.ts` | Accept optional `team` on the inbound runtime request, pass into ctx | +10 |
| `src/sessions/session-key-utils.ts` | Prepend `u:<userId>:` when team context present | +5 |
| `src/memory/*` | **No changes** | 0 |
| `src/skills/*` | **No changes** | 0 |
| `src/plugins/*` | **No changes** | 0 |

**~15 lines of patches** is the entire agent-side surface area for team mode. That is the design's strongest property.
